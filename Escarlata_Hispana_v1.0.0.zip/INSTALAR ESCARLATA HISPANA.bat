@echo off
setlocal
cd /d "%~dp0"
title Instalar Escarlata Hispana
cls
echo ================================================
echo             ESCARLATA HISPANA
echo ================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Para preparar esta copia se necesita Node.js.
  echo Instala Node.js y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm no esta disponible.
  pause
  exit /b 1
)
echo Preparando Escarlata Hispana...
call npm install
if errorlevel 1 goto :error
call npm run dist
if errorlevel 1 goto :error
set "SETUP="
for /f "delims=" %%F in ('dir /b /a-d /o-d "dist\Instalador-Escarlata-Hispana-*.exe" 2^>nul') do if not defined SETUP set "SETUP=%%F"
if not defined SETUP goto :error
cls
echo Se abrira el instalador de Escarlata Hispana.
echo El programa quedara instalado con su ejecutable Escarlata Hispana.exe
echo y se creara un acceso directo Escarlata Hispana en el escritorio.
echo.
start /wait "" "dist\%SETUP%"
exit /b 0
:error
echo.
echo ERROR: No se pudo preparar o instalar Escarlata Hispana.
pause
exit /b 1
