# Escarlata Hispana

Launcher de la comunidad Escarlata Hispana para Poke Idle World.

Versión actual: **1.0.0**.

Las versiones para Windows se publican en **Releases**. El programa comprueba automáticamente si existe una versión más reciente y también permite buscar actualizaciones desde **Opciones**.
