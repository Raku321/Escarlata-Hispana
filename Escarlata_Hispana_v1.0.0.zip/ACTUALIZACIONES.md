# Publicar una actualización

La versión base es 1.0.0.

1. Cambia `version` en `package.json` (por ejemplo, 1.0.1).
2. Sube los cambios al repositorio `Raku321/Escarlata-Hispana`.
3. Crea y sube una etiqueta con el mismo número precedido por `v` (por ejemplo, `v1.0.1`).
4. GitHub Actions compilará el instalador de Windows y lo publicará en Releases.
5. Las instalaciones existentes detectarán la nueva versión al abrir el programa o al pulsar **Buscar actualizaciones** en Opciones.

No reutilices un número de versión ya publicado.
